#ifndef __SFLD__
#define __SFLD__

#define SFLD_NAME_LEN 10

void path_concat(char *p, char *f, char **n);

#endif // __SFLD__
