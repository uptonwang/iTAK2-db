For more information on downloading, installing, running and configuring InterProScan 5 please see:

https://interproscan-docs.readthedocs.io
